// *********************************************************************
// *** RGB_colour.h                    a.vreugdenhil B+Westland@20221229
// ***
// *** We maken een lijst van kleuren op basis van de kleurenkeuze
// *** van JohnyMac, de Propeller-Goeroe. Uit zijn WS2812 libary.
// ***
// *********************************************************************

// Hier staan alle definities van de kleuren die ik gebruikt.
// we hebben een 25% waarde gebruikt, 100% is veel te fel,
// en trek veel (te veel) stroom.
 
RgbColor  BLACK      (0,  0,  0) ;
RgbColor  RED        (63, 0,  0) ;
RgbColor  GREEN      (0,  63, 0) ;
RgbColor  BLUE       (0,  0,  63);
RgbColor  WHITE      (63, 63, 63);
RgbColor  CYAN       (0,  63, 63);
RgbColor  MAGENTA    (63, 0,  63);
RgbColor  YELLOW     (63, 63, 0) ;
RgbColor  CHARTREUSE (31, 63, 0) ; 
RgbColor  ORANGE     (63, 24, 0) ; 
RgbColor  AQUAMARINE (31, 63, 52); 
RgbColor  PINK       (63, 23, 23);   
RgbColor  TURQUOISE  (15, 56, 48);    
RgbColor  REALWHITE  (50, 63, 63); 
RgbColor  INDIGO     (15, 0,  31);   
RgbColor  VIOLET     (47, 31, 47);     
RgbColor  MAROON     (12, 0,  4) ;        
RgbColor  BROWN      (3,  2,  0) ;     
RgbColor  CRIMSON    (55, 10, 15);    
RgbColor  PURPLE     (35, 0,  63);        

// *********************************************
// *** Hieronder staan de 100 % waardes,
// *** maar die zijn veel te fel cq
// *** gebruiken veel te veel stroom.
// *********************************************
/* 
#define  BLACK     (00,  0,    0)
#define  RED       (255, 0,    0)
#define  GREEN     (0,   255,  0)
#define  BLUE       (0,   0,    255)
#define  WHITE      (255, 255,  255)
#define  CYAN       (0,   255,  255)
#define  MAGENTA    (255, 0,    255)
#define  YELLOW     (255, 255,  0)
#define  CHARTREUSE (127, 255,  0)  
#define  ORANGE     (255, 96,   0)    
#define  AQUAMARINE (127, 255,  212)  
#define  PINK       (255, 95,   95)   
#define  TURQUOISE  (63,  224,  192)    
#define  REALWHITE  (200, 255,  255)   
#define  INDIGO     (63,  0,    127)   
#define  VIOLET     (191, 127,  191)     
#define  MAROON     (50,  0,    16)         
#define  BROWN      (14,  6,    0)      
#define  CRIMSON    (220, 40,   60)    
#define  PURPLE     (140, 0,    255)     
*/
// einde lijst
